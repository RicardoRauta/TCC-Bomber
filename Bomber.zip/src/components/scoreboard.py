from src.config import Config

class Scoreboard:
    def __init__(self):
        self._current_score = 0
        #self._max_score = ScoreService.get_max_score()