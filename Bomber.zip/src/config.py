# best_05_09_2024_ab2
# Tempo: 18h 35min
# Começou 12:30, terminou 07:05
# Gerações: 787
# Pontuação máxima: 942.163
# Score 0 = 938.275
# Score 1 = 938.283
# Score 2 = 938.274
# Score 3 = 938.2510000000001
# Score 4 = 938.266
# Score 5 = 938.272
# Score 6 = 688.251
# Score 7 = 938.273
# Score 8 = 938.445
# Score 9 = 938.291
# Final Score = 913.2881
#  
# Tempo: 
# Começou 8:10, terminou XX:XX
# 
# Gerações:
# 
# Pontuação máxima:
# 
#  
class Config:
    CPU_CORE = 32
    FPS = 30

    ## Screen Information
    #SCREEN_HEIGHT = 800
    #SCREEN_WIDTH = 800
    SCREEN_HEIGHT = 400
    SCREEN_WIDTH = 400

    BLOCK_SIZE = 32
    PLAYER_SIZE = 28
    BOMB_SIZE = 30

    ## IA CONFIG

    #NEURONS = [978, 489, 4] # 978 * 489 + 489 * 5 = 480.687
    #NEURONS = [369, 184, 4] # 369 * 184 + 184 * 5 = 68.816
    #NEURONS = [190, 95, 5] # 190 * 95 + 95 * 5 = 18.525 # SENDOR TOTAL FALSE
    NEURONS = [334, 167, 5] # 334 * 167 + 167 * 5 = 55.778 + 835 = 56.613 # SENDOR TOTAL TRUE

    WEIGHTS_QTD = NEURONS[0] * NEURONS[1] + NEURONS[1] * NEURONS[2]
    WEIGHTS_RANGE = 1000

    ## MODE CONFIG

    ARENA_QTD = 256
    HUMAN_MODE = True
    LOAD = False
    SCREEN_ON = False
    SENSOR_TOTAL = True


    ## GAME CONFIG

    # Pontuação:
    # Colocou bomba
    SCORE_BOMB = 1
    # Destruiu bloco
    SCORE_BRICK = 2
    # Se explodiu
    SCORE_SELF_KILL = -400
    # Explodiu oponente
    SCORE_KILL_PLAYER = 100
    # Oponente morreu
    SCORE_OTHER_DIE = 50
    # Morreu
    SCORE_DIE = -100

    ## ARENA CONFIG
    ARENA_BLOCK = '*'
    ARENA_WALL = 'o'
    ARENA_BOMB = '0'
    ARENA_EXPLOSION = 'x'
    ARENA_VOID = '-'
    ARENA_UPGRADE_BOMB = 'b'
    ARENA_UPGRADE_POWER = 'p'
    ARENA_UPGRADE_SPEED = 's'